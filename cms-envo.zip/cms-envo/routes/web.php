<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\TestimonialController;
use App\Http\Controllers\Api\LeaderController;

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('/api')->controller(HomeController::class)->group(function () {
    
Route::get('/testimonials', [TestimonialController::class, 'index']);

Route::get('/leaders', [LeaderController::class, 'index']);

});


